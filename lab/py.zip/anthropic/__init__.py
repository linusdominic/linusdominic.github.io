"""Stand-in for the anthropic package. The shell never calls a model."""


class _Error(Exception):
    pass


APIConnectionError = RateLimitError = InternalServerError = _Error


class AsyncAnthropic:
    def __init__(self, *args, **kwargs):
        raise RuntimeError("No model is available in the browser.")
